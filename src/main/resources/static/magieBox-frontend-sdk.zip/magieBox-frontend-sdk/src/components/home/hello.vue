<template>
  <div class="sscontent">
    <div>
      <div class="denglu">
        <div class="header">
          <div class="content-header">
            <div class="content">
              <div class="right" @click="login" v-if="loginn">登录</div>
              <div class="rightt" v-else>您好，{{eos.currentAccount.name}}</div>
            </div>
          </div>
          <div class="nummoney">
            <input
              type="number"
              placeholder="请输入充值额度"
              v-model="Rechargeamount"
              oninput="value=value.replace(/[1-9]\d*.\d*|0.\d*[1-9]\d*,'')"
            >
            <div class="Activationcontract" @click="transfer">充&nbsp;&nbsp;值</div>
            <input
              type="number"
              placeholder="请输入转账额度"
              style="width:40%"
              v-model="transferamount"
              oninput="value=value.replace(/[1-9]\d*.\d*|0.\d*[1-9]\d*,'')"
            >
            <input
              type="text"
              style="width:40%;margin-left:.13rem"
              placeholder="请输入转入账户"
              v-model="Transfertoaccount"
            >
            <div class="Activationcontract" @click="withdraww(2)">转&nbsp;&nbsp;账</div>
            <input
              type="number"
              placeholder="请输入提现额度"
              v-model="tixian"
              oninput="value=value.replace(/[1-9]\d*.\d*|0.\d*[1-9]\d*,'')"
            >
            <div class="Activationcontract" @click="withdraww(1)">提&nbsp;&nbsp;现</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import "../../../static/js/scatter";
import { setTimeout, setInterval, clearInterval } from "timers";
export default {
  data() {
    return {
      loginn: true,
      quantity: 0,
      Rechargeamount: "",
      transferamount: "",
      tixian: "",
      Transfertoaccount: "",
      eos: {
        eos: 0,
        currentAccount: {},
      }
    };
  },
  methods: {
    login() {
      this.scatterr = new Scatterr(
        "EAPP_test",
        "http://192.168.0.120:8099"
      );
      var timer = setInterval(() => {
        new Login().vurrentlogin;
        if (new Login().vurrentlogin) {
          this.loginn = false;
          this.eos.currentAccount.name = new ScatterName().vurrentname;
          clearInterval(timer);
        }
      }, 1000);
    },
    async transfer(data) {
      if (this.eos.currentAccount.name) {
        if (this.Rechargeamount) {
          var quantitys = Number(this.Rechargeamount).toFixed(4) + " EOS";
          new Transfer(quantitys);
        } else {
          layer.open({
            content: "请输入充值金额",
            skin: "msg",
            time: 2
          });
        }
      } else {
        layer.open({
          content: "请先登录",
          skin: "msg",
          time: 2
        });
      }
    },
    async withdraww(num) {
      if (this.eos.currentAccount.name) {
        let self = this;
        if (num == 1 && this.Withdrawalamountt == "") {
          layer.open({
            content: "请填写提现金额",
            skin: "msg",
            time: 2
          });
          return;
        }
        if (num == 1) {
          new Withdraww(
            num,
            Number(this.tixian),
            "",
            "http://192.168.0.120:8099"
          );
        }
        if (num == 2) {
          if (num == 2 && this.transferamount == "") {
            layer.open({
              content: "请填写转账金额",
              skin: "msg",
              time: 2
            });
            return;
          }
          new Withdraww(
            num,
            Number(this.transferamount),
            this.Transfertoaccount,
            "http://192.168.0.120:8099"
          );
        }
      } else {
        layer.open({
          skin: "msg",
          time: 2,
          content: "请先登录"
        });
      }
    }
  }
};
</script>
<style lang="scss" scoped>
@import "../../assets/scss/style";

</style>
<style lang="">
.rightt {
  position: absolute;
  right: 0.1rem;
  top: 0.12rem;
  color: #2aa46d;
  width: 2rem;
  height: 0.38rem;
  line-height: 0.4rem;
  text-align: right;
  font-size: 0.16rem;
}
.rightt img {
  width: 0.26rem;
  height: 0.22rem;
}
input[type="number"] {
  -moz-appearance: textfield;
}
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
}
</style>