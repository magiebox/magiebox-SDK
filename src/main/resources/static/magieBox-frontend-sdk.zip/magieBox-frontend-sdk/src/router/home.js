export default [{
    path: "/",
    component: (resolve) => require(['../components/home/hello'], resolve), //实现懒加载,
    meta: { navShow: false, cname: '二级页面' },
}]